-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2021 at 08:12 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(102, '2014_10_12_000000_create_users_table', 1),
(103, '2014_10_12_100000_create_password_resets_table', 1),
(104, '2021_04_20_140914_create_roles_table', 1),
(105, '2021_04_29_101149_create_sales_table', 1),
(106, '2021_04_29_102004_create_products_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('minhanhpkpro@gmail.com', '$2y$10$QpCw6QhszqkEN7KJekL1HuDDA9SHKMeu1AXBLczWkCHp/5RlJiJ9m', '2021-04-29 21:58:35');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` bigint(20) NOT NULL,
  `img` varchar(255) NOT NULL,
  `category` varchar(11) NOT NULL,
  `Sale_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `img`, `category`, `Sale_id`) VALUES
(1, 'Elgato Game Capture 4K60 S+', 44000, '1843556591.jpg', 'Devices', 1),
(2, 'Fire TV Stick - Includes Alexa Voice Remote ', 4980, '1098336153.jpg', 'Devices', 2),
(3, 'Kindle Paperwhite Waterproof Wi-Fi 32GB ', 17980, '1951612855.jpg', 'Devices', 0),
(4, 'Acer AlphaLine Monitor Display 23 Inch SA230Abi', 13980, '1767597857.jpg', 'Computer', 1),
(5, 'Toshiba Laptop R73/wajun XR PC Bag Set', 46800, '1526611985.jpg', 'Computer', 3),
(6, '[Official] Fujitsu Laptop FMV LIFEBOOK AH Series', 48950, '1347445924.jpg', 'Computer', 2),
(7, 'Wild Scene Sports Mask', 1300, '1428813757.jpg', 'Sports', 1),
(8, 'Converse Shoes', 5000, 'product-9.jpg', 'Fashion', 0),
(9, 'Adidas DBH61 Women\'s Grand Court Sneakers', 6500, '1301089505.jpg', 'Shoes', 1),
(10, 'Adidas DBH42 Advanced Court Sneakers', 3410, '898130205.jpg', 'Shoes', 1),
(11, 'U airism cotton oversized crew neck T-shirt ', 1400, 'product-11.jpg', 'Fashion', 0),
(12, 'Men U Wide-Fit Long-Sleeve Sweat T-shirt', 2900, 'product-12.jpg', 'Fashion', 0),
(13, 'WOMEN RAYON LINEN SHORT COAT ', 6400, 'product-13.jpg', 'Fashion', 0),
(14, 'U AIRISM COTTON CREW NECK T-SHIRT', 5000, 'product-14.jpg', 'Fashion', 0),
(15, 'Pocketable UV Protection Parka', 5000, 'product-15.jpg', 'Fashion', 0),
(16, 'Waffle Crew Neck Long-Sleeve T-Shirt', 7000, 'product-16.jpg', 'Fashion', 0),
(17, 'DRY COLOR CREW NECK SHORT-SLEEVE T-SHIRT', 2000, 'product-17.jpg', 'Fashion', 0),
(18, 'MEN DRY V-NECK SHORT-SLEEVE COLOR T-SHIRT', 1000, 'product-18.jpg', 'Fashion', 0),
(19, 'Sweater', 4000, 'product-1.jpg', 'Fashion', 1),
(20, 'Guangzhou sweater', 20000, 'product-2.jpg', 'Fashion', 2),
(21, 'Guangzhou sweater coat', 35000, 'product-3.jpg', 'Fashion', 1),
(22, 'Microfiber Wool Scarf', 18000, 'product-4.jpg', 'Fashion', 3),
(23, 'Men\'s Painted Hat', 10000, 'product-5.jpg', 'Fashion', 2),
(24, 'Sweater', 18000, 'product-6.jpg', 'Fashion', 2),
(25, 'Pure Pineapple', 3000, 'product-7.jpg', 'Fashion', 0),
(26, '2 Layer Windbreaker', 60000, 'product-8.jpg', 'Fashion', 0),
(27, 'Kids UV protection 2-way stretch Hat', 4000, 'product-10.jpg', 'Fashion', 0),
(28, 'Adidas LITE ADIRACER ADAPT 4.0 Men\'s Sneakers', 5090, '653598742.jpg', 'Shoes', 2),
(38, '【NEWモデル】Fire HD 10 タブレット 10.1インチHDディスプレイ 32GB デニム', 15000, '686359774.jpg', 'Devices', 0),
(39, 'Dell Compact Desktop Inspiron 3881', 70000, '640204330.jpg', 'Computer', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'user', '2021-04-29 19:13:24', '2021-04-29 19:13:24'),
(2, 'admin', '2021-04-29 19:13:24', '2021-04-29 19:13:24');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `percent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `percent`, `created_at`, `updated_at`) VALUES
(0, '0', '2021-04-29 19:13:24', '2021-04-29 19:13:24'),
(1, '10', '2021-04-29 19:13:24', '2021-04-29 19:13:24'),
(2, '20', '2021-04-29 19:13:24', '2021-04-29 19:13:24'),
(3, '30', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Trần Thị Tuyết Minh', 'minhanhpkpro@gmail.com', NULL, '$2y$10$0nROpadeuJUfWjr4HjoAuOFYXNwwBl1ddj6xSWP0iC0kBNIQ2i8YO', 1, NULL, '2021-04-29 21:54:37', '2021-04-29 21:54:37'),
(2, 'admin', 'admin@gmail.com', NULL, '$2y$10$dI1sga0.3A4VurhgW5ge7.nqcj8Ex6v8QEIMZ5OoyiyeDyBS4tSnC', 2, NULL, '2021-05-01 18:23:50', '2021-05-01 18:23:50');

-- --------------------------------------------------------

--
-- Table structure for table `view_user`
--

CREATE TABLE `view_user` (
  `id` int(11) NOT NULL,
  `count` bigint(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `view_user`
--

INSERT INTO `view_user` (`id`, `count`, `time`) VALUES
(1, 11, '2021-05-03 18:07:04'),
(2, 12, '2021-05-03 18:08:56'),
(3, 13, '2021-05-03 18:09:23'),
(4, 14, '2021-05-03 18:09:24'),
(5, 15, '2021-05-03 18:09:52'),
(6, 16, '2021-05-03 18:11:05'),
(7, 17, '2021-05-03 18:11:06'),
(8, 18, '2021-05-03 18:11:07'),
(9, 19, '2021-05-03 18:11:09'),
(10, 20, '2021-05-03 18:11:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `view_user`
--
ALTER TABLE `view_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `view_user`
--
ALTER TABLE `view_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
